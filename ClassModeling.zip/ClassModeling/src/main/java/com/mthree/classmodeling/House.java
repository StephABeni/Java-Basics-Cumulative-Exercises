/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.classmodeling;

import java.util.*;
        
/**
 *
 * @author steph
 * Model a house as if the class were to be part of a GPS mapping system.
Model a house as if the class were to be part of a 3-D design system.
 */
public class House {
    private String address;
    private int sqFt;
    ArrayList<Integer> rooms = new ArrayList<Integer>();
    
    public String GetAddress(){ return address; } 
    public int GetSqFt(){ return sqFt; }
    public ArrayList GetRooms(){ return rooms; }
    
    public void SetAddress(String add) { this.address = add; }
    public void SetSqFt(int feet) { this.sqFt = feet; }
    public void SetRooms(int area) {rooms.add(area); }
    
    public House(){} //default constructor
    public House(String add, int feet, ArrayList<Integer> roomSizes){
        this.address = add;
        this.sqFt = feet;
        rooms = roomSizes;
    }
}
