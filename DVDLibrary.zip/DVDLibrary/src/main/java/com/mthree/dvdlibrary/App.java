/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.dvdlibrary;

import com.mthree.dvdlibrary.controller.*;
import com.mthree.dvdlibrary.dao.*;
import com.mthree.dvdlibrary.ui.*;
/**
 *
 * @author steph
 */
public class App {
    public static void main(String[] args){
        UserIO myIO = new UserIOConsoleImpl();
        LibraryView myView = new LibraryView(myIO);
        LibraryDao myDao = new LibraryDaoFileImpl();
        LibraryController controller = new LibraryController(myView, myDao);
        controller.run();
    }
}
