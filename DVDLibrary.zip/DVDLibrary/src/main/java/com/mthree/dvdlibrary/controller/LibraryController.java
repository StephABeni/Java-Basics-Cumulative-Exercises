/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.dvdlibrary.controller;

import com.mthree.dvdlibrary.ui.*;
import com.mthree.dvdlibrary.dao.*;
import com.mthree.dvdlibrary.dto.*;
import java.util.*;

/**
 *
 * @author steph    
 */
public class LibraryController {
    private UserIO io = new UserIOConsoleImpl();
    private LibraryView view;
    private LibraryDao dao;
    
    public LibraryController(LibraryView view, LibraryDao dao){
        this.view = view;
        this.dao = dao;
    }
    
    public void run(){
        boolean hasQuit = false;
        int menuChoice = 0;
        
        try{
            while(!hasQuit){
                menuChoice = view.printMenuAndGetSelection();

                switch (menuChoice) {
                    case 1: //add
                        createDvd();
                        break;
                    case 2: //remove
                        removeDvd();
                        break;
                    case 3: //edit
                        editDvd();
                        break;
                    case 4: //list all
                        listDvds();
                        break;
                    case 5: //display info
                        viewDvd();
                        break;
                    case 6: //search by title
                        searchForDvd();
                        break;
                    case 7: //save and quit
                        hasQuit = true;
                        io.print("Goodbye!");
                        break;
                }
            }
        } catch(LibraryDaoException e){
            view.displayErrorMessage(e.getMessage());
        }
    }
    
    private void createDvd() throws LibraryDaoException{
        view.displayNewDvdBanner();
        boolean successful = false;
        while(!successful){
            String title = view.getDvdTitleChoice();                    //get title from user
            if(dao.isDuplicate(title)){                                 //if there is an existing match in hashmap
                int choice = view.duplicateRecord(dao.getDvd(title));   //get decision from user
                if(choice == 1){ //edit existing
                    view.displayEditBanner();
                    DVD oldDvd = dao.getDvd(title);
                    view.editDvdInfo(oldDvd);
                    dao.addDvd(title, oldDvd);
                    view.displaySuccessBanner();
                    successful = true;
                }   //else (2) == get new title choice from user. continue loop
            } else {    //unique title entered, add as normal
                DVD newDvd = view.getNewDvdInfo(title);
                dao.addDvd(newDvd.getTitle(), newDvd);
                view.displaySuccessBanner();
                successful = true;
            }
        }
    }
    
    private void listDvds() throws LibraryDaoException{
        view.displayListBanner();
        List<DVD> dvds = dao.getAllDvds();
        view.displayDvdList(dvds);
    }
    
    private void viewDvd() throws LibraryDaoException{
        view.displayDvdBanner();
        String title = view.getDvdTitleChoice();
        DVD dvd = dao.getDvd(title);
        view.displayDvd(dvd);
    }
    
    private void removeDvd() throws LibraryDaoException{
        view.displayRemoveBanner();
        String title = view.getDvdTitleChoice();
        DVD removedDvd = dao.removeDvd(title);
        view.displayRemoveResult(removedDvd);
    }
    
    private void editDvd() throws LibraryDaoException{
        view.displayEditBanner();
        String title = view.getDvdTitleChoice();
        DVD oldDvd = dao.getDvd(title);
        DVD newDvd = view.editDvdInfo(oldDvd);
        if(newDvd != null){
            dao.addDvd(title, oldDvd);
            view.displaySuccessBanner();
        }        
    }
    
    private void searchForDvd() throws LibraryDaoException{
        view.displaySearchBanner();
        String search = view.getDvdTitleChoice();
        ArrayList<DVD> matches = dao.searchHashMap(search);
        view.displayMatch(matches);
    }
}
