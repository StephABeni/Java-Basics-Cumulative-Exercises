/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.dvdlibrary.dao;

import com.mthree.dvdlibrary.dto.*;
import java.util.*;
import java.io.*;
import com.mthree.dvdlibrary.ui.*;

/**
 *
 * @author steph
 */
public class LibraryDaoFileImpl implements LibraryDao{
    private Map<String, DVD> dvds = new HashMap<>();
    public static final String COLLECTION_FILE = "DvdCollection.txt";   //will save and write to this specific file
    public static final String DELIMITER = "::";
    private LibraryView view;
    
    /*checks if key(title) already exists in hashmap*/
    @Override
    public Boolean isDuplicate(String title) throws LibraryDaoException{
        loadDvdCollectionFile();
        return dvds.containsKey(title);
    }
    
    /*searches hashmap for keys(titles) with partial matches. returns array with
    all partial matches*/
    @Override
    public ArrayList<DVD> searchHashMap(String partialKey) throws LibraryDaoException{
        loadDvdCollectionFile();
        ArrayList<DVD> matches = new ArrayList();
        for(String title : dvds.keySet()){
            if(dvds.get(title).getTitle().contains(partialKey)){
                matches.add(dvds.get(title));
            }
        }
        return matches;
    }
    
    /*adds entry to hashmap and saves to file*/
    @Override
    public DVD addDvd(String title, DVD dvd) throws LibraryDaoException {
        loadDvdCollectionFile();
        DVD newDvd = dvds.put(title, dvd);
        writeDvdCollectionFile();
        return newDvd;
    }

    /*returns arraylist of all dvd objects in hashmap*/
    @Override
    public List<DVD> getAllDvds() throws LibraryDaoException {
        loadDvdCollectionFile();
        return new ArrayList(dvds.values());
    }
    
    /*return dvd object with a title that matches a hashmap key*/
    @Override
    public DVD getDvd(String title) throws LibraryDaoException {
        loadDvdCollectionFile();
        return dvds.get(title);
    }

    /*removes dvd from hashmap and saves changes to file*/
    @Override
    public DVD removeDvd(String title) throws LibraryDaoException {
        loadDvdCollectionFile();
        DVD removedDvd = dvds.remove(title);
        writeDvdCollectionFile();
        return removedDvd;
    }
    
    /*splits dvd data saved in text file(DvdCollection.txt)
    into tokens to be turned back into a DVD object & returned*/
    private DVD unmarshallDvd(String dvdAsText){
        String dvdTokens[] = dvdAsText.split(DELIMITER);

        DVD dvdFromFile = new DVD(dvdTokens[0]);
        dvdFromFile.setReleaseDate(dvdTokens[1]);
        dvdFromFile.setMpaaRating(dvdTokens[2]);
        dvdFromFile.setDirectorName(dvdTokens[3]);
        dvdFromFile.setStudio(dvdTokens[4]);
        dvdFromFile.setUserNote(dvdTokens[5]);
        
        return dvdFromFile;
    }
    
    /*loads DvdCollection.txt into memory and reads it*/
    private void loadDvdCollectionFile() throws LibraryDaoException {
        Scanner scanner;
        try{
            scanner = new Scanner(new BufferedReader(new FileReader(COLLECTION_FILE)));
        }catch(FileNotFoundException e){
            throw new LibraryDaoException(
            "Could not load data into memory.", e);
        }
        
        String currentLine;
        DVD currentDvd;
        while(scanner.hasNextLine()){
            currentLine = scanner.nextLine();
            currentDvd = unmarshallDvd(currentLine);
            dvds.put(currentDvd.getTitle(), currentDvd);
        }
        scanner.close();
    }
    
    /*combines dvd object into single string to be uploaded to DvdCollection.txt*/
    private String marshallDvd(DVD dvd){
        String dvdAsText = dvd.getTitle() + DELIMITER;
        dvdAsText += dvd.getReleaseDate() + DELIMITER;
        dvdAsText += dvd.getMpaaRating() + DELIMITER;
        dvdAsText += dvd.getDirectorName() + DELIMITER;
        dvdAsText += dvd.getStudio() + DELIMITER;
        dvdAsText += dvd.getUserNote();
        
        return dvdAsText;
    }
    
    /*saves all dvds to DvdCollection.txt*/
    private void writeDvdCollectionFile() throws LibraryDaoException{
        PrintWriter out;
        try{
            out = new PrintWriter(new FileWriter(COLLECTION_FILE));
        }catch(IOException e){
            throw new LibraryDaoException("Could not save DVD data.", e);
        }
        
        String dvdAsText;
        List<DVD> dvdList = this.getAllDvds();
        for(DVD dvd : dvdList){
            dvdAsText = marshallDvd(dvd);
            out.println(dvdAsText);
            out.flush();
        }
        
        out.close();
    }
}
