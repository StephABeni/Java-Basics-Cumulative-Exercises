/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.dvdlibrary.ui;

import com.mthree.dvdlibrary.dto.DVD;
import java.util.*;

/**
 *
 * @author steph
 */
public class LibraryView {
    private UserIO io;
    
    public LibraryView(UserIO io){
        this.io = io;
    }
    
    public int printMenuAndGetSelection(){
        io.print("=== MAIN MENU ===");
        io.print("1. Add DVD");
        io.print("2. Remove DVD");
        io.print("3. Edit Existing DVD Info");
        io.print("4. List All Existing DVDs");
        io.print("5. Display DVD Info");
        io.print("6. Search for DVD by Title");
        io.print("7. Quit");

        return io.readInt("\nSelect one of the above options :\n ", true, 1, 7);
    }
    
    /*reads fields from user, sets up a DVD object, and returns it*/
    public DVD getNewDvdInfo(String title){
        String releaseDate = io.readDate(String.format("Please enter %s's release date (mm/dd/yyyy) : ", title));
        String mpaaRating = io.readString(String.format("Please enter %s's MPAA rating : ", title), false);
        String directorName = io.readString(String.format("Please enter the name of %s's director : ", title), false);
        String studio = io.readString(String.format("Please enter the studio that produced %s : ", title), false);
        String userNote = io.readString(String.format("Please enter any notes or personal ratings for %s : ", title), true);
        
        DVD currentDvd = new DVD(title);
        currentDvd.setReleaseDate(releaseDate);
        currentDvd.setMpaaRating(mpaaRating);
        currentDvd.setDirectorName(directorName);
        currentDvd.setStudio(studio);
        if(userNote.isEmpty()){ currentDvd.setUserNote("N/A"); }
        else { currentDvd.setUserNote(userNote); }
             
        return currentDvd;
    }
    
    public void displayNewDvdBanner(){
        io.print("\n=== New DVD ===\n");
    }
    
    public void displaySuccessBanner(){
        io.readString("\nSuccess! Please hit enter to continue.\n", true);
    }
    
    public void displayDvdList(List<DVD> dvds){
        if(dvds.isEmpty()){
            io.print("No DVD's in list currently.");
        } else {
            for(DVD dvd : dvds){
                printDvdInfo(dvd);
            }
        }
        io.readString("\nPlease hit enter to continue.\n", true);
    }
    
    public void displayListBanner(){
        io.print("\n=== Display All DVDs ===\n");
    }
    
    public void displayDvdBanner(){
        io.print("\n=== Display DVD ===\n");
    }
    
    public String getDvdTitleChoice(){
        return io.readString("Please enter the movie title : ", false);
    }
    
    public void displayDvd(DVD dvd){
        if(dvd != null){
            printDvdInfo(dvd);
        } else {    
            io.print("DVD not found.");
        }
        
        io.readString("\nPlease hit enter to continue.\n", true);
    }
    
    public void displayRemoveBanner(){
        io.print("\n=== Remove DVD ===\n");
    }
    
    public void displayRemoveResult(DVD record){
        if(record != null){
            io.print("DVD successfully removed.");                
        } else {
            io.print("DVD not found.");
        }
        
        io.readString("\nPlease hit enter to continue.\n", true);
    }
    
    public void displayEditBanner(){
        io.print("\n=== Edit DVD ===\n");
    }
    
    /*allows the user to edit everything except the title, 
    since the title acts as the hashmap key. returns updated dvd object*/
    public DVD editDvdInfo(DVD dvd){
        if(dvd != null){   
            boolean hasQuit = false;
            int menuChoice = 0;

            while(!hasQuit){
                String selectText = 
                    String.format("What field would you like to edit for the movie %s?\n"
                    + "    1. Release Date   (Current: %s)\n"
                    + "    2. MPAA Rating    (Current: %s)\n"
                    + "    3. Director Name  (Current: %s)\n"
                    + "    4. Studio         (Current: %s)\n"
                    + "    5. User Note      (Current: %s)\n"
                    + "    6. Exit edit mode", 
                    dvd.getTitle(), 
                    dvd.getReleaseDate(),
                    dvd.getMpaaRating(),
                    dvd.getDirectorName(),
                    dvd.getStudio(),
                    dvd.getUserNote());
                
                menuChoice = io.readInt(selectText, true, 1, 6);

                switch (menuChoice) {
                    case 1: 
                        dvd.setReleaseDate(io.readDate(String.format("Please enter %s's release date (mm/dd/yyyy) : ", dvd.getTitle())));
                        break;
                    case 2: 
                        dvd.setMpaaRating(io.readString(String.format("Please enter %s's MPAA rating : ", dvd.getTitle()), false));
                        break;
                    case 3: 
                        dvd.setDirectorName(io.readString(String.format("Please enter the name of %s's director : ", dvd.getTitle()), false));
                        break;
                    case 4: 
                        dvd.setStudio(io.readString(String.format("Please enter the studio that produced %s : ", dvd.getTitle()), false));
                        break;
                    case 5: 
                        dvd.setUserNote(io.readString(String.format("Please enter any notes or personal ratings for %s : ", dvd.getTitle()), true));
                        break;
                    case 6: 
                        hasQuit = true;
                        break;
                }
            }           
        } else {
            io.print("DVD not found.\n");
            return null;
        }
        return dvd;
    }
    
    private void printDvdInfo(DVD dvd){
        String dvdInfo = 
            String.format("%s : \n    Release - %s\n    MPAA - %s\n"
            + "    Director - %s\n    Studio - %s\n    Notes - %s",
            dvd.getTitle(),
            dvd.getReleaseDate(),
            dvd.getMpaaRating(),
            dvd.getDirectorName(),
            dvd.getStudio(),
            dvd.getUserNote());
        io.print(dvdInfo);
    }
    
    public void displayErrorMessage(String errorMsg){
        io.print("=== ERROR ===");
        io.print(errorMsg);
    }
    
    public int duplicateRecord(DVD dvd){
        io.print("DVD with matching title found. Unable to add movies with the same title, did you mean to edit the below movie?");
        printDvdInfo(dvd);
        int choice = io.readInt("Select one of the below options: \n"
                + "    1.Edit the existing record\n"
                + "    2.Change title entry",
                true, 1, 2);
        return choice;
    }
    
    public void displaySearchBanner(){
        io.print("=== BEGINNING SEARCH ===");
    }
    
    public void displayMatch(ArrayList<DVD> matches){
        if(matches.size() == 1){
            io.print("\nMatch found!\n");
            printDvdInfo(matches.get(0));
        } else if (matches.size() > 1){
            io.print("\nMultiple Matches! All matches listed below:\n ");
            for(DVD dvd : matches){
                printDvdInfo(dvd);
            }
        } else {
            io.print("\nNo Matches Found.\n ");
        }
        io.readString("\nPlease hit enter to continue.\n", true);
    }
}
