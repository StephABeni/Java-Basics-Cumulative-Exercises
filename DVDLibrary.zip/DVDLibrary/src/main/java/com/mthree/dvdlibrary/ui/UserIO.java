/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.dvdlibrary.ui;

/**
 *
 * @author steph
 */
public interface UserIO {
    void print(String msg);
    
    String readString(String prompt, boolean allowBlanks);

    int readInt(String prompt, boolean limited, int min, int max); 
    
    String readDate(String prompt);
    
    boolean isValidDate(int month, int day, int year);
}
