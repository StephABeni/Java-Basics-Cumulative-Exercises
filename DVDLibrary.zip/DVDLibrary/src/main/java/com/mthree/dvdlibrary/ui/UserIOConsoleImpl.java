/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.dvdlibrary.ui;

import java.util.*;


/**
 *
 * @author steph
 */
public class UserIOConsoleImpl implements UserIO{
    final private Scanner input = new Scanner(System.in);
    
    @Override
    public void print(String msg){
        System.out.println(msg);
    }
    
    @Override
    public String readString(String prompt, boolean allowBlanks){
        if(allowBlanks){
            print(prompt);
            return input.nextLine();
        } else {
            boolean isValid = false;
            String userData = "";
            while(!isValid){
                print(prompt);
                userData = input.nextLine(); //get number from user
                if(!userData.isEmpty()){    //make sure it isn't empty
                    isValid = true;
                } else {
                    print("No input entered.");
                }
            }
            return userData;
        }
    }

    @Override
    public int readInt(String prompt, boolean limited, int min, int max){   
        int number = -1;       
        boolean isValid = false;
        
        while(!isValid) {
            String userData = readString(prompt, false);    //get string from user
            try{
                number = Integer.parseInt(userData);        //parse it into an int
            } catch (java.lang.NumberFormatException e){
                print("Integer not entered.");              //loop again if non-int entered
                continue;
            }
            isValid = true;
            
            if(limited){    //check if number needs to be within a certain range
                if (number < min || number > max){
                    print("Invalid Entry.\n");
                    isValid = false;    //loop again if it isn't
                }
            }
        }   
        
        return number;
    }
    
    @Override
    public String readDate(String prompt){      
        int month, day, year;
        boolean isValid = false;
        String date = "";
        
        while(!isValid){  
            date = readString(prompt, false);   //get string from user
            String[] splitDate = date.split("/", 3);    //split string based on / as delimiter
         
            try{
                month = Integer.parseInt(splitDate[0]); 
                day = Integer.parseInt(splitDate[1]);
                year = Integer.parseInt(splitDate[2]);
            } catch (java.lang.NumberFormatException e){
                print("Invalid date format");  //loop again if non-int entered
                continue;
            }
            
            //make sure it conforms to the format mm/dd/yyyy
            if(splitDate[0].length() != 2 || splitDate[1].length() != 2 || splitDate[2].length() != 4)
            {
                print("Invalid date format");
                continue;
            }
           
            isValid = isValidDate(month, day, year);    //check if date is possible
            if(!isValid){
                print("Invalid date");
            }
        }   
        return date;
    }
    
    @Override
    public boolean isValidDate(int month, int day, int year){
        int nonLeapYear[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        int leapYear[] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        boolean isLeap;
        
        //make sure basic values match mm/dd/yyyy
        if((month < 1 || month > 12) || (day < 1 || day > 31) || (year < 0 || year > 9999)){
            return false;
        }
        
        if (year % 4 == 0){ //check if it's a leap year
            if(year % 100 == 0){
                if(year % 400 == 0){
                    isLeap = true;
                } else {
                    isLeap = false;
                }
            } else {
                isLeap = true;
            }
        } else {
            isLeap = false;
        }
        
        if(isLeap){ //check if the day entered is within the range for that month/year combo
            if(leapYear[month-1] < day) { return false; }
        } else {
            if(nonLeapYear[month-1] < day) { return false; }
        }
        
        return true;
    }
}
