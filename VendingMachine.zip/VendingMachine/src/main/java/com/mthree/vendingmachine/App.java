/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine;
    
import com.mthree.vendingmachine.controller.*;
import com.mthree.vendingmachine.dao.*;
import com.mthree.vendingmachine.ui.*;
import com.mthree.vendingmachine.service.*;

/**
 *
 * @author steph
 */
public class App {
    public static void main(String[] args){
        UserIO myIO = new UserIOConsoleImpl();
        VendingMachineView myView = new VendingMachineView(myIO);
        VendingMachineDao myDao = new VendingMachineDaoFileImpl();
        VendingMachineAuditDaoInt myAuditDao = new VendingMachineAuditDao();
        VendingMachineServiceLayer myServiceLayer = new VendingMachineServiceLayer(myDao, myAuditDao);
        VendingMachineController controller = new VendingMachineController(myView, myServiceLayer);
        controller.run();
    }
}
