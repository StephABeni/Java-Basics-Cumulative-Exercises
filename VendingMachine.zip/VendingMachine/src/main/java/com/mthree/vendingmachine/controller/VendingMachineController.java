/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.controller;

import com.mthree.vendingmachine.ui.*;
import com.mthree.vendingmachine.dao.*;
import com.mthree.vendingmachine.dto.*;
import com.mthree.vendingmachine.service.*;
import java.util.*;
import java.math.*;

/**
 *
 * @author steph    
 */

public class VendingMachineController {
    private UserIO io = new UserIOConsoleImpl();
    private VendingMachineView view;
    private VendingMachineServiceLayer serviceLayer;
    BigDecimal shopperMoney;
    
    public VendingMachineController(VendingMachineView view, VendingMachineServiceLayer serviceLayer){
        this.view = view;
        this.serviceLayer = serviceLayer;
        this.shopperMoney = new BigDecimal("0.00");
        this.shopperMoney.setScale(2, RoundingMode.HALF_UP);
    }
    
    public void run(){
        boolean hasQuit = false;
        
        while(!hasQuit){
            try{
                view.displayMessage("=== VENDING MACHINE ===");
                view.displayInventory(serviceLayer.getAllItems());
                shopperMoney = view.getMoneyFromUser();
                
                if(shopperMoney.floatValue() == 0.00f){
                    hasQuit = true;
                    view.displayMessage("You're leaving the vending machine. Goodbye!");
                } else if (shopperMoney.intValue() == 3151995) {   //secret key to restock machine
                    restockMachine();
                } else { 
                    view.displayMessage("You've successfully put in $" + shopperMoney.toString() + ".");

                    int inventorySize = serviceLayer.getAllItems().size();
                    int purchaseChoice = view.getPurchaseChoice(serviceLayer.getAllItems());
                    purchaseItem(purchaseChoice); //purchase item
                }
            }         
            catch(VendingMachineDaoException|InsufficientFundsException|NoItemInventoryException e){    
                view.displayMessage(e.getMessage());
                try{ changeHelper(); } catch(VendingMachineDaoException e2){ view.displayMessage(e2.getMessage()); }
            }
        }
    }
    
    private void restockMachine() throws VendingMachineDaoException{
        ArrayList<InventoryItem> currentInventory = serviceLayer.getAllItems(); 
        int itemChoice = view.displayInventoryAndGetRestockSelection(currentInventory);
        
        InventoryItem restockedItem = currentInventory.get(itemChoice-1);  
        restockedItem.setAmountLeft(view.getAmountToAdd(restockedItem));
       
        serviceLayer.addItem(restockedItem.getName(), restockedItem);
    }
    
    private void purchaseItem(int itemChoice) 
            throws InsufficientFundsException, NoItemInventoryException, VendingMachineDaoException{
        ArrayList<InventoryItem> currentInventory = serviceLayer.getAllItems(); //check if they have enough money
        InventoryItem currentItem = currentInventory.get(itemChoice-1);    
        
        serviceLayer.validatePurchase(shopperMoney, currentItem);

        BigDecimal currentCost = new BigDecimal(String.valueOf(currentItem.getCost()));
        shopperMoney = shopperMoney.subtract(currentCost);  //subtract cost of item from money put in
        view.displayMessage("\n*Whirrrr Whirrr Whiirr .... KA-CHUNK*\nYour purchase of " + currentItem.getName() + " was successful!");
        
        serviceLayer.updateItem(currentItem);    //update the item amount
        changeHelper();     
    }
    
    private void changeHelper() throws VendingMachineDaoException{
        view.displayRemaining(shopperMoney);    //display total change
        Integer coins[] = serviceLayer.makeChange(shopperMoney);
        view.displayChange(coins);  //display coins they'll get back
    }
}
