/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.dao;

import com.mthree.vendingmachine.dto.*;
import java.util.*;
import java.math.*;
/**
 *
 * @author steph
 */
public interface VendingMachineDao {
    InventoryItem addItem(String title, InventoryItem item) throws VendingMachineDaoException;
    ArrayList<InventoryItem> getAllItems() throws VendingMachineDaoException;
    InventoryItem getItem(String title) throws VendingMachineDaoException;
    InventoryItem updateItem(InventoryItem currentItem) throws VendingMachineDaoException;
    Boolean isDuplicate(String name) throws VendingMachineDaoException;
    Integer[] makeChange(BigDecimal remaining) throws VendingMachineDaoException;
};