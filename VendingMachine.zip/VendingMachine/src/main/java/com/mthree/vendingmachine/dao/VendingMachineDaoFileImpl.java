/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.dao;

import com.mthree.vendingmachine.dto.*;
import com.mthree.vendingmachine.ui.*;
import java.util.*;
import java.io.*;
import java.math.*;
import java.util.stream.*;


/**
 *
 * @author steph
 */

public class VendingMachineDaoFileImpl implements VendingMachineDao{
    private Map<String, InventoryItem> vendingMachine = new HashMap<>();
    public final String COLLECTION_FILE;   //will save and write to this specific file
    public static final String DELIMITER = "::";
    private VendingMachineView view;
    private VendingMachineAuditDaoInt auditDao = new VendingMachineAuditDao();
    
    public VendingMachineDaoFileImpl(){
        COLLECTION_FILE = "VendingMachineInventory.txt";
    }
    
    public VendingMachineDaoFileImpl(String textFileName){
        COLLECTION_FILE = textFileName;
    } 
    
    /*adds entry to hashmap and saves to file*/
    @Override
    public InventoryItem addItem(String name, InventoryItem item) throws VendingMachineDaoException {
        loadFile();
        InventoryItem newItem = vendingMachine.put(name, item);
        auditDao.writeAuditEntry("Item " + item.getName() + " ADDED.");
        writeToFile();
        return newItem;
    }
    
    /*returns arraylist of all objects in hashmap*/
    @Override
    public ArrayList<InventoryItem> getAllItems() throws VendingMachineDaoException {
        loadFile();
        return new ArrayList(vendingMachine.values());
    }
    
    /*return object with a name that matches a hashmap key*/
    @Override
    public InventoryItem getItem(String name) throws VendingMachineDaoException {
        loadFile();
        ArrayList<InventoryItem> items = new ArrayList(vendingMachine.values());
        List<InventoryItem> item = items.stream()
                .filter((i) -> i.getName() == name)
                .collect(Collectors.toList());
        auditDao.writeAuditEntry("Item " + item.get(0).getName() + " GOTTEN.");
        return item.get(0);
        //return vendingMachine.get(name);
    }

    /*removes item from hashmap and saves changes to file*/
    @Override
    public InventoryItem updateItem(InventoryItem currentItem) throws VendingMachineDaoException {
        loadFile();
        currentItem.setAmountLeft(currentItem.getAmountLeft()-1);
        vendingMachine.replace(currentItem.getName(), currentItem);
        auditDao.writeAuditEntry("Item " + currentItem.getName() + " UPDATED.");
        writeToFile();
        return currentItem;
    }
    
     /*checks if object of same name already exists in hashmap*/
    @Override
    public Boolean isDuplicate(String name) throws VendingMachineDaoException{
        loadFile();
        return vendingMachine.containsKey(name);
    }
    
    /*returns bigdecimal change in coins given a value (using enums)*/
    @Override
    public Integer[] makeChange(BigDecimal remaining){     
        Integer memo[] = {0, 0, 0, 0};  //Quarters[0], dimes[1], nickles[2], pennies[3]

        while (remaining.compareTo(Coin.QUARTER.getValue()) >= 0){
            memo[0] += 1;
            remaining = remaining.subtract(Coin.QUARTER.getValue());
        }
        while (remaining.compareTo(Coin.DIME.getValue()) >= 0){
            memo[1] += 1;
            remaining = remaining.subtract(Coin.DIME.getValue());
        }
        while (remaining.compareTo(Coin.NICKLE.getValue()) >= 0){
            memo[2] += 1;
            remaining = remaining.subtract(Coin.NICKLE.getValue());
        }
        while (remaining.compareTo(Coin.PENNY.getValue()) >= 0){
            memo[3] += 1;
            remaining = remaining.subtract(Coin.PENNY.getValue());
        }
        return memo;
    }

    /*splits data saved in text file
    into tokens to be turned back into an object & returned*/
    private InventoryItem unmarshallInventory(String itemAsText){
        String itemTokens[] = itemAsText.split(DELIMITER);
        BigDecimal cost = new BigDecimal(itemTokens[1]);
        InventoryItem itemFromFile = new InventoryItem(itemTokens[0]);
        itemFromFile.setCost(cost);
        itemFromFile.setAmountLeft(Integer.parseInt(itemTokens[2]));
        
        return itemFromFile;
    }
    
    /*combines object into single string to be uploaded to textFile*/
    private String marshallInventory(InventoryItem item){
        String itemAsText = item.getName() + DELIMITER;
        itemAsText += item.getCost() + DELIMITER;
        itemAsText += item.getAmountLeft();
        
        return itemAsText;
    }
    
    /*loads textfile into memory and reads it*/
    private void loadFile() throws VendingMachineDaoException {
        Scanner scanner;
        try{
            scanner = new Scanner(new BufferedReader(new FileReader(COLLECTION_FILE)));
        }catch(FileNotFoundException e){
            throw new VendingMachineDaoException(
            "Could not load data into memory.", e);
        }
        
        String currentLine;
        InventoryItem currentItem;
        while(scanner.hasNextLine()){
            currentLine = scanner.nextLine();
            currentItem = unmarshallInventory(currentLine);
            vendingMachine.put(currentItem.getName(), currentItem);
        }
        scanner.close();
    }
    
    /*saves all objects to testfile*/
    private void writeToFile() throws VendingMachineDaoException{
        PrintWriter out;
        try{
            out = new PrintWriter(new FileWriter(COLLECTION_FILE));
        }catch(IOException e){
            throw new VendingMachineDaoException("Could not save DVD data.", e);
        }
        
        String itemAsText;
        List<InventoryItem> vendingInventory = this.getAllItems();
        for(InventoryItem item : vendingInventory){
            itemAsText = marshallInventory(item);
            out.println(itemAsText);
            out.flush();
        }
        
        out.close();
    }
}
