/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.dto;

import java.math.*;
/**
 *
 * @author steph
 */
public enum Coin {
    QUARTER("0.25"),
    DIME("0.10"),
    NICKLE("0.05"),
    PENNY("0.01");
    
    private BigDecimal value;
    
    private Coin(String value){
        this.value = new BigDecimal(value);
    }
    
    public BigDecimal getValue(){
        return this.value;
    }
}
