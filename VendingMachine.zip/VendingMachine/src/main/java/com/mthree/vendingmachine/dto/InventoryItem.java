/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.dto;

import java.math.*;
import java.util.Objects;
/**
 *
 * @author steph
 */
public class InventoryItem {
    private String name;
    private BigDecimal cost;
    private int amountLeft;
    
    public InventoryItem(String name){
        this.name = name;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + Objects.hashCode(this.name);
        hash = 23 * hash + Objects.hashCode(this.cost);
        hash = 23 * hash + this.amountLeft;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final InventoryItem other = (InventoryItem) obj;
        if (this.amountLeft != other.amountLeft) {
            return false;
        }
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.cost, other.cost)) {
            return false;
        }
        return true;
    }
    
    public String getName(){ return name; }
    public void setName(String name) { this.name = name; }
    
    public BigDecimal getCost(){ return cost; }
    public void setCost(BigDecimal cost) { this.cost = cost; }
    
    public int getAmountLeft(){ return amountLeft; }
    public void setAmountLeft(int amountLeft) { this.amountLeft = amountLeft; }
}
