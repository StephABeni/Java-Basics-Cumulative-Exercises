/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.service;

import com.mthree.vendingmachine.dao.*;
import com.mthree.vendingmachine.dto.*;
import java.util.*;
import java.math.*;
/**
 *
 * @author steph
 */
public class VendingMachineServiceLayer{
    VendingMachineDao dao;
    private VendingMachineAuditDaoInt auditDao;
    
    public VendingMachineServiceLayer(VendingMachineDao dao, VendingMachineAuditDaoInt auditDao){
        this.dao = dao;
        this.auditDao = auditDao;
    }
    
    public void validatePurchase(BigDecimal shopperMoney, InventoryItem currentItem) 
            throws InsufficientFundsException, NoItemInventoryException{
        if(shopperMoney.compareTo(currentItem.getCost()) < 0)
            throw new InsufficientFundsException(
                "\nInsufficient funds. The item costs $" + currentItem.getCost() + 
                " and you only have $" + shopperMoney.toString() + ".\n");
        if(currentItem.getAmountLeft() <= 0)
            throw new NoItemInventoryException("\n" + currentItem.getName() + " is out of stock.\n");
                
    }
    
    public InventoryItem addItem(String name, InventoryItem item) throws VendingMachineDaoException {
        return dao.addItem(name, item);
    }
    
    public ArrayList<InventoryItem> getAllItems() throws VendingMachineDaoException {
        return dao.getAllItems();
    }
    
    public InventoryItem getItem(String name) throws VendingMachineDaoException {
        return dao.getItem(name);
    }

    public InventoryItem updateItem(InventoryItem currentItem) throws VendingMachineDaoException {
        return dao.updateItem(currentItem);
    }
    
    public Boolean isDuplicate(String name) throws VendingMachineDaoException{
        return dao.isDuplicate(name);
    }
    
    public Integer[] makeChange(BigDecimal remaining) throws VendingMachineDaoException{     
        return dao.makeChange(remaining);
    }
}
