/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.ui;

import java.util.*;
import java.math.*;
/**
 *
 * @author steph
 */
public class UserIOConsoleImpl implements UserIO{
     final private Scanner input = new Scanner(System.in);
    
    public void print(String msg){
        System.out.println(msg);
    }
    
    public String readString(String prompt, boolean allowBlanks){
        if(allowBlanks){
            print(prompt);
            return input.nextLine();
        } else {
            boolean isValid = false;
            String userData = "";
            while(!isValid){
                print(prompt);
                userData = input.nextLine(); //get number from user
                if(!userData.isEmpty()){    //make sure it isn't empty
                    isValid = true;
                } else {
                    print("No input entered.");
                }
            }
            return userData;
        }
    }

    public int readInt(String prompt, boolean limited, int min, int max){   
        int number = -1;       
        boolean isValid = false;
        
        while(!isValid) {
            String userData = readString(prompt, false);    //get string from user
            try{
                number = Integer.parseInt(userData);        //parse it into an int
            } catch (java.lang.NumberFormatException e){
                print("Integer not entered.");              //loop again if non-int entered
                continue;
            }
            isValid = true;
            
            if(limited){    //check if number needs to be within a certain range
                if (number < min || number > max){
                    print("Invalid Entry.\n");
                    isValid = false;    //loop again if it isn't
                }
            }
        }   
        
        return number;
    }
    
    public BigDecimal readMoney(String prompt, boolean limited, float min, float max){
        BigDecimal money = new BigDecimal("0.00");   
        boolean isValid = false;
        
        while(!isValid) {
            String userData = readString(prompt, false);    //get string from user
            try{
                money = new BigDecimal(userData).setScale(2, RoundingMode.HALF_UP);      //parse it into a BigDecimal
            } catch (java.lang.NumberFormatException e){
                print("Money value not entered.");              //loop again if non-int entered
                continue;
            }
            
            isValid = true;
            
            if(limited){    //check if number needs to be within a certain range
                if (money.floatValue() < min || money.floatValue() > max){
                    print("Invalid Entry.\n");
                    isValid = false;    //loop again if it isn't
                }
            }
        }   
        
        return money;
    }
}
