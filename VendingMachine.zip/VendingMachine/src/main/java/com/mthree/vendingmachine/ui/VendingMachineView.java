/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.ui;

import com.mthree.vendingmachine.dto.*;
import java.util.*;
import java.math.*;


/**
 *
 * @author steph
 */
public class VendingMachineView {
    private UserIO io;
    
    public VendingMachineView(UserIO io){
        this.io = io;
    }
    
    public void displayInventory(ArrayList<InventoryItem> inventory){
        int counter = 1;
        for(InventoryItem item : inventory){
            printInventoryItem(item, counter);
            counter++;
        }
    }
    
    public BigDecimal getMoneyFromUser(){
        return io.readMoney("\nEnter funds now (i.e. 5, 5.0, or 5.00), or enter 0 to leave the vending machine : ", true, 0.00f, 3151995.00f);   
    }
    
    public int getPurchaseChoice(ArrayList<InventoryItem> inventory){
        displayInventory(inventory);
        return io.readInt("\nPlease enter the number of the item you would you like to purchase :", true, 1, inventory.size());
    }
    
    public int displayInventoryAndGetRestockSelection(ArrayList<InventoryItem> inventory){
        io.print("=== CURRENT VENDING MACHINE STOCK ===");
        displayInventory(inventory);
        return io.readInt("\nSelect one of the above options : ", true, 1, inventory.size()+1); 
    }
    
    public void printInventoryItem(InventoryItem item, int count){
        io.print("" + count + ". " + item.getName());
        io.print("    Cost : " + item.getCost());
        io.print("    In Stock : " + item.getAmountLeft());
    }
    
    public void displayErrorMessage(){
        io.print("Error! Exiting.");
    }
    
    public void displayMessage(String message){
        io.print(message);
    }
    
    public int getAmountToAdd(InventoryItem item){
        return io.readInt("\nHow many total '" + item.getName() + "' do you want in the vending machine?", true, 0, 9999); 
    }
    
    public void displayRemaining(BigDecimal money){
        io.print("\nReturning change : $" + money.toString());
    }
    
    public void displayChange(Integer coins[]){
        io.print("    Quarters : " + coins[0]);
        io.print("    Dimes : " + coins[1]);
        io.print("    Nickles : " + coins[2]);
        io.print("    Pennies : " + coins[3] + "\n");
    }
    
    public void displayOutOfStock(InventoryItem item){
        io.print("\n" + item.getName() + " is out of stock.\n");
    }
}
