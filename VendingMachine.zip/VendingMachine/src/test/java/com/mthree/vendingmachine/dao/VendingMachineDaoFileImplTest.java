/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

import com.mthree.vendingmachine.dto.*;
import java.math.*;
import java.util.*;
import java.io.*;
/**
 *
 * @author steph
 */
public class VendingMachineDaoFileImplTest { 
    VendingMachineDao testDao;
    
    public VendingMachineDaoFileImplTest() {
    }
    
    @BeforeEach
    public void setUp() throws Exception{
        //Use the FileWriter to quickly blank the file
        String testFile = "testVendingMachine.txt";
        new FileWriter(testFile);
        testDao = new VendingMachineDaoFileImpl(testFile);
    }
    
    @Test
    public void testAddGetItem() throws VendingMachineDaoException{
        try{ setUp(); } catch (Exception e) {}
        InventoryItem testItem = new InventoryItem("AddGetTester");
        testItem.setCost(new BigDecimal("2.00"));
        testItem.setAmountLeft(1);
        
        testDao.addItem(testItem.getName(), testItem);  //add new item to dao
        InventoryItem retrievedItem = testDao.getItem(testItem.getName());  //retrieve it
        
        //check data is equal
        assertEquals(testItem.getName(), retrievedItem.getName(), "Checking Name.");
        assertEquals(testItem.getCost(), retrievedItem.getCost(), "Checking Cost.");
        assertEquals(testItem.getAmountLeft(), retrievedItem.getAmountLeft(), "Checking Amount Left.");
    }
    
    @Test
    public void testGetAllItems() throws VendingMachineDaoException{
        try{ setUp(); } catch (Exception e) {}
        InventoryItem testItem = new InventoryItem("GetAllTester1");
        testItem.setCost(new BigDecimal("1.00"));
        testItem.setAmountLeft(1);
        
        InventoryItem testItem2 = new InventoryItem("GetAllTester2");
        testItem2.setCost(new BigDecimal("3.00"));
        testItem2.setAmountLeft(2);
        
        testDao.addItem(testItem.getName(), testItem);
        testDao.addItem(testItem2.getName(), testItem2);  
        
        ArrayList<InventoryItem> allItems = testDao.getAllItems();
        
        assertNotNull(allItems, "The list of items must not be null.");
        assertEquals(2, allItems.size(), "List of items should have 2 items.");
        assertTrue(testDao.getAllItems().contains(testItem),
                "The list of items should include GetAllTester1.");
        assertTrue(testDao.getAllItems().contains(testItem2),
            "The list of items should include CetAllTester2.");
    }
    
    @Test
    public void testUpdateItem() throws VendingMachineDaoException{
        try{ setUp(); } catch (Exception e) {}
        InventoryItem testItem = new InventoryItem("UpdateTester");
        testItem.setCost(new BigDecimal("2.00"));
        testItem.setAmountLeft(1);
        
        testDao.addItem(testItem.getName(), testItem);
        InventoryItem updatedItem = testDao.updateItem(testItem);
        
        assertEquals(testItem.getName(), updatedItem.getName(), "Checking Name.");
        assertEquals(testItem.getCost(), updatedItem.getCost(), "Checking Cost.");
        assertEquals(updatedItem.getAmountLeft(), 0, "Amount left should = 0.");
    }
    
    @Test
    public void testMakeChange() throws VendingMachineDaoException{
        try{ setUp(); } catch (Exception e) {}
        BigDecimal change = new BigDecimal("1.94");
        
        Integer[] changeResult = testDao.makeChange(change);
        
        assertEquals(changeResult[0], 7, "Should be 7 Quarters.");
        assertEquals(changeResult[1], 1, "Should be 1 Dimes.");
        assertEquals(changeResult[2], 1, "Should be 1 Nickles.");
        assertEquals(changeResult[3], 4, "Should be 4 Pennies.");
    }
}
