/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.service;
import com.mthree.vendingmachine.dto.*;
import com.mthree.vendingmachine.dao.*;
import java.math.*;
import java.util.*;
/**
 *
 * @author steph
 */
public class VendingMachineDaoStub implements VendingMachineDao{
    public InventoryItem onlyItem;
    
    public VendingMachineDaoStub(){
        onlyItem = new InventoryItem("TestItem");
        onlyItem.setCost(new BigDecimal("1.00"));
        onlyItem.setAmountLeft(1);   
    }
    
    public VendingMachineDaoStub(InventoryItem newItem){
        this.onlyItem = newItem;
    }
    
        
    @Override
    public InventoryItem addItem(String name, InventoryItem item) throws VendingMachineDaoException{
        if(name.equals(onlyItem.getName())){
            return onlyItem;
        } else {
            return null;
        }
    }  
    
    @Override
    public ArrayList<InventoryItem> getAllItems() throws VendingMachineDaoException{
        ArrayList<InventoryItem> itemList = new ArrayList<>();
        itemList.add(onlyItem);
        return itemList;
    }
    
    @Override
    public InventoryItem getItem(String name) throws VendingMachineDaoException{
        if(name.equals(onlyItem.getName())){
            return onlyItem;
        } else {
            return null;
        }
    }
    
    @Override
    public InventoryItem updateItem(InventoryItem currentItem) throws VendingMachineDaoException{
        if(currentItem.getName().equals(onlyItem.getName())){
            onlyItem.setAmountLeft(onlyItem.getAmountLeft()-1);
            return onlyItem;
        } else{
            return null;
        }          
    }
    
    @Override
    public Boolean isDuplicate(String name) throws VendingMachineDaoException{
        if(name.equals(onlyItem.getName())){
            return true;
        } else {
            return false;
        }
    }
    
    @Override
    public Integer[] makeChange(BigDecimal remaining) throws VendingMachineDaoException{
        return new Integer[] {7, 1, 1, 4};      
    }
}
