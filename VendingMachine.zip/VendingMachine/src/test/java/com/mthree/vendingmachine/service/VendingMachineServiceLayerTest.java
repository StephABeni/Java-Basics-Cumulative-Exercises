/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.vendingmachine.service;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import com.mthree.vendingmachine.dao.*;
import com.mthree.vendingmachine.dto.*;
import java.math.*;
import java.util.*;

/**
 *
 * @author steph
 */

public class VendingMachineServiceLayerTest {
    VendingMachineDao testDao = new VendingMachineDaoStub();
    private VendingMachineAuditDaoInt auditDao = new VendingMachineAuditDaoStub();
    VendingMachineServiceLayer testServiceLayer = new VendingMachineServiceLayer(testDao, auditDao);
    
    
    public VendingMachineServiceLayerTest() {
    }
    
    @Test
    public void testValidPurchase() throws VendingMachineDaoException, InsufficientFundsException, NoItemInventoryException{
        try{
            testServiceLayer.validatePurchase(new BigDecimal("1.00"), testServiceLayer.getItem("TestItem"));
        } catch (VendingMachineDaoException|InsufficientFundsException|NoItemInventoryException e){
            fail("Could not Purchase, exception thrown");
        }        
    }
    
    
    public void testInsufficientFunds() throws InsufficientFundsException{
        try{
            testServiceLayer.validatePurchase(new BigDecimal("0.50"), testServiceLayer.getItem("TestItem"));
        } catch (VendingMachineDaoException|NoItemInventoryException e){
            fail("Failed Test. Wrong Exception Thrown.");
        } catch (InsufficientFundsException e){
            return;
        }
    }
    
    public void testNoItemInventory() throws NoItemInventoryException{
        try{
            testServiceLayer.validatePurchase(new BigDecimal("1.00"), testServiceLayer.getItem("TestItem"));
        } catch (VendingMachineDaoException|InsufficientFundsException e){
            fail("Failed Test. Wrong Exception Thrown.");
        } catch (NoItemInventoryException e){
            return;
        }
    }
}
