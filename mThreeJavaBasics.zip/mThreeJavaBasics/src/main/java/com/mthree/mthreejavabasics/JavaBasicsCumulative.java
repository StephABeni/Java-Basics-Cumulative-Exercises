/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.mthreejavabasics;

/**
 * @author Stephanie Benamati
 * email: stephabenamati@gmail.com
 * purpose: Java Basics Cumulative work
 */

import java.util.*;

public class JavaBasicsCumulative{
    public static void main(String[] args) {
        int selection = 0;       
        do{     //main will continue to run until user chooses to quit
           selection = getUserNumber("Which exercise would you like to test?\n1 - Rock, Paper, Scissors\n2 - Dog Genetics\n3 - Healthy Hearts\n4 - Summative Sums\n5 - Quit", true, 1, 5); 
            
            switch(selection){
                case 1:
                    RockPaperScissors();
                    break;
                case 2:
                    DogGenetics();
                    break;
                case 3:
                    HealthyHearts();
                    break;
                case 4:
                    SummativeSums();
                    break;
                case 5:
                    System.out.println("You've chosen to quit the program. Goodbye!");
                    break;
            }
        } while (selection != 5);
    }
    
    public static void RockPaperScissors(){
        System.out.println("You've chosen to play Rock, Paper, Scissors!");
        int rps = 0;        //player choice
        int compRps = 0;    //computer 'choice'
        
        int tracking[] = {0,0,0,0}; //rounds[0], wins[1], ties[2], losses[3], 
        
        tracking[0] = getUserNumber("How many rounds would you like to play? (1-10)", false, 0, 0);
        if(tracking[0] < 1 || tracking[0] > 10){    //exit if invalid rounds entered
            System.out.println("Invalid Round Amount. Exiting!");
            return;
        }
        while (tracking[0] > 0){    //while rounds remain, keep playing R.P.S.
            String roundsString = 
                    String.format("%d Round(s) Remaining : Wins = %d, Ties = %d, Losses = %d", tracking[0], tracking[1], tracking[2], tracking[3]);
            System.out.println(roundsString);
            rps = getUserNumber("Enter '1' for Rock, '2' for Paper, or '3' for Scissors.", true, 1, 3);            
            compRps = getRandomInt(1,3);
            
            tracking[getRoundResult(rps, compRps)]++;     //update round results
            tracking[0]--;                                //update while loop, one less round
        }  
        
        String resultString = String.format("Final Result : Wins = %d, Ties = %d, Losses = %d\n", tracking[1], tracking[2], tracking[3]);
        System.out.println(resultString);
        if(tracking[1] > tracking [3]){             //print results of RPS game
            System.out.println("*** VICTORY! ***");
        } else if (tracking[3] > tracking[1]) {
            System.out.println("*** DEFEAT! ***");
        } else {
            System.out.println("*** TIE! ***");
        }
        
        int replay = getUserNumber("Do you want to play again? \n1 - Yes \n2 - No", true, 1, 2);    //replay RPS if player wants, else go back to main
        if(replay == 1){
            RockPaperScissors();
        }        
    }
    
    /*accounting for player choice and the randomized computer choice, 
    logic out if it's a win, a tie, or a loss, then return the result */
    public static int getRoundResult(int playerChoice, int compChoice){
        if(playerChoice == 1){
            System.out.println("You've chosen Rock.");
            if(compChoice == 1){
                System.out.println("Your opponent's chosen Rock. You Tie!");
                return 2; 
            }
            else if (compChoice == 2) { 
                System.out.println("Your opponent's chosen Paper. You Lose!");
                return 3; 
            }
            else { 
                System.out.println("Your opponent's chosen Scissors. You Win!");
                return 1; 
            }
        } else if (playerChoice == 2){
            System.out.println("You've chosen Paper.");
            if(compChoice == 1){ 
                System.out.println("Your opponent's chosen Rock. You Win!");
                return 1; 
            }
            else if (compChoice == 2) { 
                System.out.println("Your opponent's chosen Paper. You Tie!");
                return 2; 
            }
            else { 
                System.out.println("Your opponent's chosen Scissors. You Lose!");
                return 3; 
            }
        } else {
            System.out.println("You've chosen Scissors.");
            if(playerChoice == 1){ 
                System.out.println("Your opponent's chosen Rock. You Lose!");
                return 3; 
            }
            else if (compChoice == 2) { 
                System.out.println("Your opponent's chosen Paper. You Win!");
                return 1; 
            }
            else { 
                System.out.println("Your opponent's chosen Scissors. You Tie!");
                return 2; 
            }
        }    
    }
    
    public static int getUserNumber(String promptText, boolean limited, int min, int max){
        System.out.println(promptText);     
        Scanner input = new Scanner(System.in);
        int number = -1;       
        boolean isValid = false;
        
        do{
            String userData = input.nextLine(); //get number from user
            if(!userData.isEmpty()){    //make sure it isn't empty
                try{
                    number = Integer.parseInt(userData);    //parse it into an int
                } catch (java.lang.NumberFormatException e){
                    System.out.println("Number not entered.");  //loop again if non-int entered
                    continue;
                }
                isValid = true;
            } else {
                System.out.println("No input entered.");
            }
            
            if(limited){    //check if number is within a certain range
                if (number < min || number > max){
                    System.out.println("Invalid Entry.\n");
                    System.out.println(promptText);
                    isValid = false;    //loop again if it isn't
                }
            }
        }while(!isValid);    
        
        return number;
    }
    
    /*return random number within a predefined range of ints*/
    public static int getRandomInt(int min, int max){
        Random rand = new Random();
        int result = rand.nextInt(max-min) + min;
        return result;
    }
    
    /*get a string from the user, validating that it is not empty before
    returning it*/
    public static String getUserInput(String promptText){
        System.out.println(promptText);
        Scanner input = new Scanner(System.in);
        String userData = input.nextLine();
        
        while(userData.trim().isEmpty()){
            System.out.println("Nothing entered.");
            System.out.println(promptText);
            input = new Scanner(System.in);
            userData = input.nextLine();
        }
        
        return userData;           
    }
    
    public static void DogGenetics(){
        System.out.println("You've chosen to check your Dog's Genetics!");
        String dogName = getUserInput("What is your dog's name?");
        
        int total = 100;
        int percentages[] = {0,0,0,0,0};
        String breeds[] = {"Husky", "Golden Retriever", "Pharoh Hound", "Pug", "Poodle"};
        int counter = 0;
        int breedPercent = 0;
        
        while (total > 0){
            do{                 //make sure there's always at least 1% remaining for other breeds
                breedPercent = getRandomInt(1,100);
            }while((total-breedPercent) < (4-counter));
                
            if(counter == 4)    //the last breed gets whatever is left to total 100%
                breedPercent = total;
            
            percentages[counter] = breedPercent;    //update tracking array and loop variables
            total -= breedPercent;
            counter++;
        }
        
        String resultString = String.format("%s is :\n%d%s %s \n%d%s %s \n%d%s %s \n%d%s %s \n%d%s %s", dogName, percentages[0], "%", breeds[0], 
                percentages[1], "%", breeds[1], percentages[2], "%", breeds[2], percentages[3], "%", breeds[3], percentages[4], "%", breeds[4]);
        System.out.println(resultString);   //print results
    }
    
    public static void HealthyHearts(){
        System.out.println("You've chosen to check your Healthy Heart Rate!");
        int heartRate = getUserNumber("What is your age? (Choose an age between 1-150)", true, 1, 150);
        int max = 220 - heartRate;
        int zoneMin = Math.round(max*(50.0f/100f));
        int zoneMax = Math.round(max*(85.0f/100f));
        
        String resultString = String.format("Your maximum heart rate should be %d beats per minute\n", max);
        System.out.println(resultString);
        resultString = String.format("Your target HR Zone is %d - %d beats per minute\n", zoneMin, zoneMax);
        System.out.println(resultString);
    }
    
    public static void SummativeSums(){
        int array1[] = { 1, 90, -33, -55, 67, -16, 28, -55, 15 };
        int array2[] = { 999, -60, -77, 14, 160, 301 };
        int array3[] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200, -99 };
        
        int twoD[][] = {array1, array2, array3};    //create 2d array with other arrays inside
        
        for(int i = 0; i < 3; i++){ //nested for loop to go through each item in each array
            int sum = 0;
            for(int j = 0; j < twoD[i].length; j++){
                sum += twoD[i][j];  //cumulative sum of each array
            }
            String resultString = String.format("#%d Array Sum: %d", i+1, sum);
            System.out.println(resultString);   //print results
        }
    }
}

